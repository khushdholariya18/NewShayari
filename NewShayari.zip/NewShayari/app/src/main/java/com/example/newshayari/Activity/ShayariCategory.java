package com.example.newshayari.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.newshayari.Apdter.categoryAdpter;
import com.example.newshayari.R;

public class ShayariCategory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView;

        listView =  findViewById(R.id.list);

            categoryAdpter ca = new categoryAdpter(this);

            listView.setAdapter(ca);


    }
}